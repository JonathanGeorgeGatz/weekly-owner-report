/* The Weekly Owner Report — FIRST BUILD (prompt 1 output), kept verbatim for the episode.
   Three real faults, exactly as the first session produced them:
   (1) "this week" = the calendar week containing the newest row — a Wednesday export
       makes it a 3-day week compared against last FULL week;
   (2) expense categories matched against ITS OWN keyword list; anything unmatched is
       silently absent from the breakdown and the spend total;
   (3) money = every row with qty > 0 — VOIDED lines count as revenue, REFUNDED rows
       (negative qty) are filtered out entirely. */
(function (g) {
  "use strict";
  const DAY = 86400000;
  function monday(t) { const d = new Date(t); const w = (d.getUTCDay() + 6) % 7; return t - w * DAY; }
  function r2(x) { return Math.round(x * 100) / 100; }
  function fmtD(t) { return new Date(t).toLocaleDateString("en-US", { month: "short", day: "numeric", timeZone: "UTC" }); }
  const KEYWORDS = { Rent: ["rent"], Payroll: ["payroll", "gusto"], Inventory: ["stock", "soil", "seed", "tool restock", "grower", "wholesale"], Utilities: ["water", "sewer", "electric", "power", "gas"], "Card fees": ["square", "fees", "stripe"], Insurance: ["insurance"] };
  function analyze(salesCsv, expCsv, settings) {
    const S = Object.assign({ baselineWeeks: 4, moverPct: 25, dupDays: 3, topN: 5 }, settings || {});
    const sales = [], expenses = [];
    const sl = salesCsv.split(/\r?\n/);
    let maxT = -Infinity;
    for (let i = 1; i < sl.length; i++) {
      if (!sl[i].trim()) continue;
      const c = sl[i].split(",");
      const t = Date.parse(c[0] + "T00:00:00Z");
      const qty = Number(c[4]), total = Number(c[6]);
      if (!isFinite(t) || !isFinite(qty) || qty <= 0 || !isFinite(total)) continue;   // refunds vanish here
      if (t > maxT) maxT = t;
      sales.push({ t, item: c[2], qty, total });                                       // VOIDED still in
    }
    const el = expCsv.split(/\r?\n/);
    for (let i = 1; i < el.length; i++) {
      if (!el[i].trim()) continue;
      const c = el[i].split(",");
      const t = Date.parse(c[0] + "T00:00:00Z");
      const amt = Number(c[3]);
      if (!isFinite(t) || !isFinite(amt)) continue;
      if (t > maxT) maxT = t;
      expenses.push({ t, desc: (c[1] || "") + " " + (c[4] || ""), ven: c[2] || "", amt });
    }
    const wkStart = monday(maxT);                      // the partial "this week"
    const wkEnd = wkStart + 6 * DAY;
    const prevStart = wkStart - 7 * DAY, prevEnd = wkStart - DAY;
    let revenue = 0, prevRevenue = 0, units = 0;
    const perItem = new Map();
    for (const s of sales) {
      if (s.t >= wkStart && s.t <= wkEnd) {
        revenue += s.total; units += s.qty;
        const r = perItem.get(s.item) || { wk: 0, prev: 0 };
        r.wk += s.total; perItem.set(s.item, r);
      } else if (s.t >= prevStart && s.t <= prevEnd) {
        prevRevenue += s.total;
        const r = perItem.get(s.item) || { wk: 0, prev: 0 };
        r.prev += s.total; perItem.set(s.item, r);
      }
    }
    const products = [...perItem.entries()].map(([item, r]) => ({ item, revenue: r2(r.wk), prev: r2(r.prev), pct: r.prev > 0 ? Math.round((r.wk - r.prev) / r.prev * 100) : null })).sort((a, b) => b.revenue - a.revenue);
    const catMap = new Map();
    let spend = 0;
    for (const e of expenses) {
      if (e.t < wkStart || e.t > wkEnd) continue;
      const hay = (e.desc + " " + e.ven).toLowerCase();
      let hit = null;
      for (const k in KEYWORDS) if (KEYWORDS[k].some(w => hay.includes(w))) { hit = k; break; }
      if (!hit) continue;                               // <- silently gone
      catMap.set(hit, r2((catMap.get(hit) || 0) + e.amt));
      spend += e.amt;
    }
    return {
      week: { start: wkStart, end: wkEnd, label: fmtD(wkStart) + " – " + fmtD(wkEnd) },
      money: { revenue: r2(revenue), prevRevenue: r2(prevRevenue), pct: prevRevenue > 0 ? Math.round((revenue - prevRevenue) / prevRevenue * 100) : null, units, cashOut: r2(spend), net: r2(revenue - spend) },
      top: products.slice(0, S.topN),
      categories: [...catMap.entries()].map(([name, total]) => ({ name, total })).sort((a, b) => b.total - a.total)
    };
  }
  g.WR_V1 = { analyze };
})(typeof window !== "undefined" ? window : (typeof module !== "undefined" ? module.exports : this));
