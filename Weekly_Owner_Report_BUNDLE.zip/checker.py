#!/usr/bin/env python3
"""Independent checker for The Weekly Owner Report — a from-scratch Python
implementation of the same spec. Shares no code with the tool. stdin: JSON
{sales, expenses, settings} -> stdout: JSON report matching engine.js fields."""
import sys, json, datetime as dt

DAY = 86400

def iso(s):
    try:
        d = dt.date.fromisoformat(s.strip())
        return int(dt.datetime(d.year, d.month, d.day, tzinfo=dt.timezone.utc).timestamp())
    except Exception:
        return None

def monday(t):
    d = dt.datetime.fromtimestamp(t, dt.timezone.utc)
    return t - ((d.weekday()) * DAY)

import math
def jround(x):
    return int(math.floor(x + 0.5))

def r2(x):
    # match JS Math.round(x*100)/100 exactly (half toward +infinity)
    return math.floor(x * 100 + 0.5) / 100.0

def fmtd(t):
    d = dt.datetime.fromtimestamp(t, dt.timezone.utc)
    return d.strftime("%b ") + str(d.day)

def num(s):
    s = (s or "").strip()
    if not s:
        return None
    try:
        return float(s)
    except Exception:
        return None

def main():
    inp = json.load(sys.stdin)
    S = {"baselineWeeks": 4, "moverPct": 25, "dupDays": 3, "topN": 5}
    S.update(inp.get("settings") or {})
    refused = []
    sales = []
    sl = inp["sales"].split("\n")
    head = [h.strip().lower() for h in sl[0].split(",")]
    ix = {k: head.index(k) for k in ("date", "item", "category", "qty", "unit_price", "line_total", "status")}
    maxT = None
    for i in range(1, len(sl)):
        if not sl[i].strip():
            continue
        c = sl[i].split(",")
        t = iso(c[ix["date"]])
        if t is None:
            refused.append({"file": "sales", "line": i + 1}); continue
        q, p, tot = num(c[ix["qty"]]), num(c[ix["unit_price"]]), num(c[ix["line_total"]])
        if q is None or q == 0:
            refused.append({"file": "sales", "line": i + 1}); continue
        if p is None or tot is None:
            refused.append({"file": "sales", "line": i + 1}); continue
        st = c[ix["status"]].strip().upper()
        if st not in ("PAID", "REFUNDED", "VOIDED"):
            refused.append({"file": "sales", "line": i + 1}); continue
        if abs(q * p - tot) > 0.005 + abs(tot) * 1e-9:
            refused.append({"file": "sales", "line": i + 1}); continue
        maxT = t if maxT is None else max(maxT, t)
        sales.append((t, c[ix["item"]].strip(), c[ix["category"]].strip(), q, jround(tot * 100), st))  # cents
    exps = []
    el = inp["expenses"].split("\n")
    eh = [h.strip().lower() for h in el[0].split(",")]
    ex = {k: eh.index(k) for k in ("date", "description", "vendor", "amount", "category")}
    for i in range(1, len(el)):
        if not el[i].strip():
            continue
        c = el[i].split(",")
        t = iso(c[ex["date"]])
        if t is None:
            refused.append({"file": "expenses", "line": i + 1}); continue
        a = num(c[ex["amount"]])
        if a is None:
            refused.append({"file": "expenses", "line": i + 1}); continue
        maxT = t if maxT is None else max(maxT, t)
        exps.append((t, c[ex["description"]].strip(), c[ex["vendor"]].strip(), jround(a * 100), c[ex["category"]].strip()))  # cents
    if maxT is None:
        print(json.dumps({"error": "no usable rows", "refused": len(refused)})); return

    curMon = monday(maxT)
    wk0 = curMon - 7 * DAY
    wk1 = wk0 + 6 * DAY
    partialDays = (maxT - curMon) // DAY + 1
    hist = min([s[0] for s in sales] + [e[0] for e in exps])
    firstFull = hist if hist == monday(hist) else monday(hist) + 7 * DAY
    haveWeeks = max(0, jround((wk0 - firstFull) / (7 * DAY)))
    provisional = haveWeeks < S["baselineWeeks"]

    revenue = 0; refundsWk = 0; voidedWk = 0; unitsWk = 0
    item = {}
    for (t, it, cat, q, tot, st) in sales:
        rec = item.setdefault(it, {"cat": cat, "q": 0, "rev": 0, "base": [0] * S["baselineWeeks"], "anyBase": False})
        if wk0 <= t <= wk1:
            if st == "PAID":
                revenue += tot; unitsWk += q; rec["q"] += q; rec["rev"] += tot
            elif st == "REFUNDED":
                refundsWk += -tot; revenue += tot
            else:
                voidedWk += tot
        elif st == "PAID":
            for k in range(S["baselineWeeks"]):
                b0 = wk0 - 7 * (k + 1) * DAY
                if b0 <= t <= b0 + 6 * DAY:
                    rec["base"][k] += tot; rec["anyBase"] = True
    revenue = revenue / 100.0; refundsWk = -refundsWk / 100.0 if False else refundsWk / 100.0; voidedWk = voidedWk / 100.0

    prods = []
    for it, rec in item.items():
        bavgC = sum(rec["base"]) / S["baselineWeeks"]   # cents
        if bavgC > 0:
            pct = jround((rec["rev"] - bavgC) / bavgC * 100)
        elif rec["rev"] > 0:
            pct = None
        else:
            pct = 0
        prods.append({"item": it, "qty": rec["q"], "revenue": rec["rev"] / 100.0, "baseline": jround(bavgC) / 100.0, "pct": pct, "soldBase": rec["anyBase"]})
    prods.sort(key=lambda p: -p["revenue"])
    top = [p for p in prods if p["revenue"] > 0][:S["topN"]]
    FLOOR = 40
    up = sorted([p for p in prods if p["pct"] is not None and p["pct"] >= S["moverPct"] and p["baseline"] >= FLOOR], key=lambda p: -p["pct"])
    down = sorted([p for p in prods if p["pct"] is not None and p["pct"] <= -S["moverPct"] and p["baseline"] >= FLOOR], key=lambda p: p["pct"])
    stopped = sorted([p for p in prods if p["soldBase"] and p["baseline"] >= FLOOR and p["revenue"] == 0], key=lambda p: -p["baseline"])

    cashOut = 0; cats = {}; unc = []
    for (t, desc, ven, a, cat) in exps:
        if not (wk0 <= t <= wk1):
            continue
        cashOut += a
        name = cat if cat else "Uncategorized"
        cats[name] = cats.get(name, 0) + a
        if not cat:
            unc.append({"ven": ven, "amt": a / 100.0})
    cashOut = cashOut / 100.0
    categories = sorted([{"name": k, "total": v / 100.0} for k, v in cats.items()], key=lambda c: -c["total"])
    uncTotal = jround(sum(jround(r["amt"] * 100) for r in unc)) / 100.0

    byk = {}
    for e in exps:
        byk.setdefault((e[2].lower(), "%.2f" % (e[3] / 100.0)), []).append(e)
    dups = []
    for k, lst in byk.items():
        lst.sort(key=lambda e: e[0])
        for i in range(1, len(lst)):
            gap = jround((lst[i][0] - lst[i - 1][0]) / DAY)
            if 0 < gap <= S["dupDays"]:
                dups.append({"ven": lst[i][2], "amt": lst[i][3] / 100.0, "days": gap,
                             "inWeek": (wk0 <= lst[i][0] <= wk1) or (wk0 <= lst[i - 1][0] <= wk1)})
    dups.sort(key=lambda d: -d["amt"])

    wtd = 0; prior = 0
    for (t, it, cat, q, tot, st) in sales:
        if st in ("PAID", "REFUNDED"):
            if curMon <= t <= maxT:
                wtd += tot
            if wk0 <= t <= wk0 + (partialDays - 1) * DAY:
                prior += tot

    paidSum = sum(tot for (t, it, cat, q, tot, st) in sales if wk0 <= t <= wk1 and st == "PAID") / 100.0
    refSum = sum(tot for (t, it, cat, q, tot, st) in sales if wk0 <= t <= wk1 and st == "REFUNDED") / 100.0
    totalRows = sum(1 for l in sl[1:] if l.strip()) + sum(1 for l in el[1:] if l.strip())
    rowsTie = len(sales) + len(exps) + len(refused) == totalRows
    revTie = abs((paidSum + refSum) - revenue) < 0.005
    catSum = jround(sum(jround(c["total"] * 100) for c in categories)) / 100.0
    expTie = abs(catSum - cashOut) < 0.005
    share = len(refused) / max(1, totalRows)
    trusted = rowsTie and revTie and expTie and share <= 0.02

    print(json.dumps({
        "week": {"label": fmtd(wk0) + " – " + fmtd(wk1) + ", " + str(dt.datetime.fromtimestamp(wk1, dt.timezone.utc).year), "partialDays": partialDays},
        "provisional": provisional, "haveWeeks": haveWeeks,
        "money": {"revenue": revenue, "refunds": refundsWk, "voided": voidedWk, "units": unitsWk, "cashOut": cashOut, "net": (jround(revenue * 100) - jround(cashOut * 100)) / 100.0},
        "top": top, "up": up, "down": down, "stopped": stopped,
        "categories": categories, "uncTotal": uncTotal, "uncCount": len(unc),
        "dups": dups, "wtd": {"days": partialDays, "revenue": wtd / 100.0, "priorSame": prior / 100.0},
        "refused": len(refused), "refusedLines": sorted([r["file"] + ":" + str(r["line"]) for r in refused]),
        "recon": {"totalRows": totalRows, "kept": len(sales) + len(exps), "rowsTie": rowsTie,
                  "paidSum": paidSum, "refundSum": refSum, "revTie": revTie,
                  "catSum": catSum, "expTie": expTie, "trusted": trusted}
    }))

main()
