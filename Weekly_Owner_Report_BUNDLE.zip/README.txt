THE WEEKLY OWNER REPORT — Build It With AI, Episode 12
========================================================

One page every Monday: what sold, what it cost, where the cash went —
from the two exports you already have.

WHAT'S IN THIS ZIP
  index.html           the tool. Open it in any browser. That's the install.
  sample_sales.csv     the fictional sample business (Fernline Garden Supply)
  sample_expenses.csv  its bank export
  PROMPTS.txt          the exact three prompts typed on camera, word for word
  engine_v1.js         the FIRST build's engine, kept verbatim — the one that
                       read a Wednesday export as "revenue down 73%"
  checker.py           the independent Python second opinion (shares no code
                       with the tool; run: see header in the file)

HOW TO USE IT
  1. Open index.html in a browser. Nothing is uploaded anywhere — the page
     has no internet access and never asks for any.
  2. Paste your register's sales export and your bank's spending export
     (or click "Load the sample business" to see it work first).
  3. Read the Monday page: sold / spent / kept, top products vs their
     average week, where the cash went, possible duplicate charges,
     refused rows with reasons, and a to-the-cent self-audit.

IF YOUR EXPORTS HAVE DIFFERENT COLUMN NAMES
  Hand index.html and PROMPT 1 to the AI and tell it what your register
  calls things. That's a five-minute conversation.

THE NUMBERS BEHIND IT (verified at ship time)
  17,696 fields compared against the independent checker — 0 disagreements
  26/26 functional checks in a real browser, network blocked
  4/4 visible settings verified to change the page

All sample data is fictional. From the YouTube series "Build It With AI".
